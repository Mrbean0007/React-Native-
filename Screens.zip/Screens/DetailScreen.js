import React, { Component} from 'react';
import { AppRegistry, StyleSheet, Text, TouchableOpacity, View, Button } from 'react-native';
import 'react-native-gesture-handler';

export default class DetailScreen extends Component {

    render() { 
        return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text>Details</Text>
          <Button title="Go to Details... again" onPress={() => this.props.navigation.push('Detail')} />
          <Button title="Go back" onPress={() => this.props.navigation.goBack()} />
          <Button title="Go back to first screen in stack"onPress={() => this.props.navigation.popToTop()}/>
        </View>
          
          );
        }
    }
    
    
    //   const { itemId, otherParam } = this.props.route.params;
  {/* <Text>itemId: {JSON.stringify(itemId)}</Text>
  <Text>otherParam: {JSON.stringify(otherParam)}</Text> */}